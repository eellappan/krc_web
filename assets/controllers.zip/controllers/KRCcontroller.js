app = angular.module("KRCapp",[]);

app.controller("KRCController", function ($scope, KRCService, KRCFactory) {
    
            $scope.getUrlparameter = function(){

                var board_point = GetURLParameter('from');
                var drop_point = GetURLParameter('to');
                var datej = GetURLParameter('dateJ');
                var dateR = GetURLParameter('dateR');
                post_data  ={'board_point':board_point,'drop_point':drop_point};
                link="route/select_bus";
                var promise = KRCService.GET_data(link,post_data);
                promise.then(function(response)
                { 
                    $scope.getbusdetails = response;
                    $scope.board_point = board_point;
                    $scope.drop_point = drop_point;
                    $scope.dateJ = date;
                    $scope.dateR = dateR;
                    date=new Date(date);
                    today =new Date();
                    if(today<date){
                        
                        $scope.datepre="true";
                    }else{
                        $scope.datepre="false";
                    }
                    $scope.date_slide = date.toISOString();
                    if(dateR!="undefined"){
                        dateRs=new Date(dateR);
                        $scope.date_slideR = dateRs.toISOString();
                        if(date<dateRs){
                                $scope.datenext="false";
                            }else{
                            $scope.datenext="true";	
                            }
                    }else{
                            $scope.datenext="false";
                        }
                    $(".loader").hide();
                })
                link="route/filter_option";
                var promise = KRCService.GET_data(link,post_data);
                promise.then(function(response)
                {
                    $scope.filter = response; 
                })
            }
           
      

        var index = 0;

        $scope.nextTenant = function () {
            index++;
            if (KRCFactory.isOverflow(index))
            {
                index--;
            }
            $scope.tenant = KRCFactory.getTenant(index);

        }

        $scope.previousTenant = function () {
            index--;
            if (index < 0) {
                index = 0;
            }
            $scope.tenant = KRCFactory.getTenant(index);
        }

        $scope.addTenant = function () {
            index--;
            if (index < 0) {
                index = 0;
            }
            $scope.tenant = KRCFactory.addTenant(index);
        }

        $scope.deleteTenant = function () {
         
            $scope.tenant = KRCFactory.deleteTenant(index);
            index--;
        }      

      
        function GetURLParameter(sParam) {
			var sPageURL = decodeURIComponent(window.location.search.substring(1)),
				sURLVariables = sPageURL.split('&'),
				sParameterName,
				i;

			for (i = 0; i < sURLVariables.length; i++) {
				sParameterName = sURLVariables[i].split('=');

				if (sParameterName[0] === sParam) {
					return sParameterName[1] === undefined ? true : sParameterName[1];
				}
			}
        }
    
    })
